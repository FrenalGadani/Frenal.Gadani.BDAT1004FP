﻿using Microsoft.AspNetCore.Mvc;
using ATC.API.Models;

namespace ATC.API.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class AtcDetailsController : ControllerBase
    {
        private readonly data_programmingContext _context;
        private readonly ILogger<AtcDetailsController> _logger;        

        public AtcDetailsController(data_programmingContext context, ILogger<AtcDetailsController> logger)
        {
            _context = context;
            _logger = logger;
        }

        // GET: AtcDetails
        [HttpGet]
        public IActionResult GetLatest()
        {            
            if (_context.AtcDetails != null)
            {
                var date = _context.AtcDetails.Select(a => a.CreateDate).Max();
                var time = _context.AtcDetails.Where(a=> a.CreateDate == date).Select(a => a.CreateTime).Max();
                long startId = _context.AtcDetails.Where(a => a.CreateDate == date & a.CreateTime == time).Select(a => a.Id).Min();
                long endId = _context.AtcDetails.Where(a => a.CreateDate == date & a.CreateTime == time).Select(a => a.Id).Max();
                return Ok(_context.AtcDetails.Where(a => a.Id>=startId && a.Id<=endId).ToList<AtcDetail>());
            }                
            else
                return NotFound();
        }
                
        [HttpGet("GetById/{id}")]
        public IActionResult Details(string id)
        {
            if (id == null || _context.AtcDetails == null)
            {
                return NotFound();
            }
            int numId = 0;
            Int32.TryParse(id, out numId);
            var atcDetail = _context.AtcDetails.FirstOrDefault(m => m.Id == Convert.ToInt32(numId));
            if (atcDetail == null)
            {
                return NotFound();
            }

            return Ok(atcDetail);
        }
        
        [HttpGet("GetByCountry/{countryName}")]
        public IActionResult DetailsByOriginCountry(string countryName)
        {
            if (countryName == null || _context.AtcDetails == null)
            {
                return NotFound();
            }

            int a = _context.AtcDetails.Where(a => string.IsNullOrEmpty(a.OriginCountry) == false & a.OriginCountry.ToLower().Trim() == countryName.ToLower().Trim()).Count();
            if (a == 0) 
                return NotFound();
            else
                return Ok(_context.AtcDetails.Where(a => string.IsNullOrEmpty(a.OriginCountry) == false & a.OriginCountry.ToLower().Trim() == countryName.ToLower().Trim()).ToList());                        
        }
    }
}
