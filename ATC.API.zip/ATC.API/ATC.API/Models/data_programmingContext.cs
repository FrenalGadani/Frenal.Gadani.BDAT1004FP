﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

namespace ATC.API.Models
{
    public partial class data_programmingContext : DbContext
    {
        public data_programmingContext()
        {
        }

        public data_programmingContext(DbContextOptions<data_programmingContext> options)
            : base(options)
        {
        }

        public virtual DbSet<AtcDetail> AtcDetails { get; set; } = null!;

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. You can avoid scaffolding the connection string by using the Name= syntax to read it from configuration - see https://go.microsoft.com/fwlink/?linkid=2131148. For more guidance on storing connection strings, see http://go.microsoft.com/fwlink/?LinkId=723263.
                optionsBuilder.UseSqlServer("Server=tcp:dataprogramming.database.windows.net,1433;Initial Catalog=data_programming;Persist Security Info=False;User ID=dataprgrm;Password=BDAT1004dp;MultipleActiveResultSets=False;Encrypt=True;TrustServerCertificate=False;Connection Timeout=300;");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<AtcDetail>(entity =>
            {
                entity.ToTable("ATC_Details");

                entity.Property(e => e.Id).HasColumnName("id");

                entity.Property(e => e.BaroAltitude).HasColumnName("baro_altitude");

                entity.Property(e => e.Callsign)
                    .HasMaxLength(20)
                    .IsUnicode(false)
                    .HasColumnName("callsign");

                entity.Property(e => e.CreateDate)
                    .HasColumnType("date")
                    .HasColumnName("create_date");

                entity.Property(e => e.CreateTime).HasColumnName("create_time");

                entity.Property(e => e.EpochTime).HasColumnName("epoch_time");

                entity.Property(e => e.GeoAltitude).HasColumnName("geo_altitude");

                entity.Property(e => e.Icao24)
                    .HasMaxLength(30)
                    .IsUnicode(false)
                    .HasColumnName("icao24");

                entity.Property(e => e.LastContact).HasColumnName("last_contact");

                entity.Property(e => e.Latitude).HasColumnName("latitude");

                entity.Property(e => e.Longitude).HasColumnName("longitude");

                entity.Property(e => e.OnGround).HasColumnName("on_ground");

                entity.Property(e => e.OriginCountry)
                    .HasMaxLength(200)
                    .IsUnicode(false)
                    .HasColumnName("origin_country");

                entity.Property(e => e.Position).HasColumnName("position");

                entity.Property(e => e.Sensors).HasColumnName("sensors");

                entity.Property(e => e.Spi).HasColumnName("spi");

                entity.Property(e => e.Squawk)
                    .HasMaxLength(10)
                    .IsUnicode(false)
                    .HasColumnName("squawk");

                entity.Property(e => e.TimePosition).HasColumnName("time_position");

                entity.Property(e => e.TrueTrack).HasColumnName("true_track");

                entity.Property(e => e.Velocity).HasColumnName("velocity");

                entity.Property(e => e.VerticalRate).HasColumnName("vertical_rate");
            });

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}
